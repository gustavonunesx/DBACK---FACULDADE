package aula05.exercicios.ex9;

public class Memoria {
    
    private int capacidade; 

    public Memoria(int capacidade) {
        this.capacidade = capacidade;
    }

    public int getCapacidade() {
        return capacidade;
    }

}
