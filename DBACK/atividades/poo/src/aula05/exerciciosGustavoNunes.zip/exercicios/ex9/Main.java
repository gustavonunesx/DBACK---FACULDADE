package aula05.exercicios.ex9;

public class Main {
    public static void main(String[] args) {

        Computador pc1 = new Computador("Intel i7", 16);
        pc1.exibirDetalhes();

        
        Computador pc2 = new Computador("AMD Ryzen 5", 8);
        pc2.exibirDetalhes();

    }
    
}
