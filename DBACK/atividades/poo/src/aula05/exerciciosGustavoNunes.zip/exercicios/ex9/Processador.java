package aula05.exercicios.ex9;

public class Processador {
    
    private String modelo;

    public Processador(String modelo) {
        this.modelo = modelo;
    }

    public String getModelo() {
        return modelo;
    }

}
