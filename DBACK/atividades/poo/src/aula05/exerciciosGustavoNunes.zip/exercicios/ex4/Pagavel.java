package aula05.exercicios.ex4;

public interface Pagavel {
    
    public void pagar();
}
