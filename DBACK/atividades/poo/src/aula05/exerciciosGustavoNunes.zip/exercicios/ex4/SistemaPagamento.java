package aula05.exercicios.ex4;

public class SistemaPagamento {
    
    public void processarPagamento(Pagavel pagamento) {
        pagamento.pagar(); 
    }

}
