package aula05.exercicios.ex5;

public class Main {
    public static void main(String[] args) {
        
        for (DiaDaSemana dia : DiaDaSemana.values()) {
            dia.imprimirMensagem();
        }

    }

}
