package aula05.exercicios.ex3;


public class Impressora {
    
    public void imprimirArquivo(Imprimir arquivo) {
        arquivo.imprimir(); // Chama o método imprimir de qualquer objeto que implemente Imprimivel
    }

}
