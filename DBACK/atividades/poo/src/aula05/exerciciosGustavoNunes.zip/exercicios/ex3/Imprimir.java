package aula05.exercicios.ex3;

public interface Imprimir {
    
    public void imprimir();
}
