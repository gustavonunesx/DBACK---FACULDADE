package aula05.exercicios.ex8;

public class Motor {
    
    private int potencia;

    public Motor(int potencia) {
        this.potencia = potencia;
    }

    public int getPotencia() {
        return potencia;
    }

}
