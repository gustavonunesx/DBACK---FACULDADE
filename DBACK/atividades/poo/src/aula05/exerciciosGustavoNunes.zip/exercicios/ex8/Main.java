package aula05.exercicios.ex8;

public class Main {
    public static void main(String[] args) {
        
        Carro carro1 = new Carro("Fusca", 150);
        carro1.exibirPotenciaMotor();

        Carro carro2 = new Carro("Civic", 200);
        carro2.exibirPotenciaMotor();
    

    }
}
