package aula05.exercicios.ex1;

public class Gerente extends Funcionario {
    
      public Gerente(String nome, double salario) {
        super(nome, salario);
    }

    
    @Override
    public double calcularBonus() {
        return salario * 0.20;  
    }

}
