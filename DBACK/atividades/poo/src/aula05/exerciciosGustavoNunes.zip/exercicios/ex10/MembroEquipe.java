package aula05.exercicios.ex10;

public abstract class MembroEquipe {
    protected String nome;

    public MembroEquipe(String nome) {
        this.nome = nome;
    }

    public abstract void trabalhar();


}
