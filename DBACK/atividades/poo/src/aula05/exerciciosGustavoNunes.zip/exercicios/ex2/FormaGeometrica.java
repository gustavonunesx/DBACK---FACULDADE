package aula05.exercicios.ex2;

public abstract class FormaGeometrica {

    public abstract double calcularArea();

    
}
